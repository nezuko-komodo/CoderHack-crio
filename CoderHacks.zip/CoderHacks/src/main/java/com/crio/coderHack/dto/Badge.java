package com.crio.coderHack.dto;

public enum Badge {
    CODE_NINJA, 
    CODE_CHAMP, 
    CODE_MASTER
}
